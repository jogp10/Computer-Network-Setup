gcc -o download clientTCP.c -lpthread
./download ftp://ftp.up.pt/pub/kodi/timestamp.txt